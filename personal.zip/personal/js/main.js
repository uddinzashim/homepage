$(function(){
        $("#elastic_grid_demo").elastic_grid({
            'showAllText' : 'All',
            'filterEffect': 'popup', // moveup, scaleup, fallperspective, fly, flip, helix , popup
            'hoverDirection': true,
            'hoverDelay': 0,
            'hoverInverse': false,
            'expandingSpeed': 500,
            'expandingHeight':5000,
            'items' :
            [
                {
                    'title'         : 'BULLSY',
                    'description'   : 'BULLSY is a parallel computing platform and programming model invented by NVIDIA. It enables dramatic increases in computing performance by harnessing the power of the graphics processing uni',
                    'thumbnail'     : ['images/small/bullsy.jpg'],
                    'large'         : ['images/large/bullsy.jpg'],
                    'button_list'   :
                    [
                        { 'title':'Demo', 'url' : 'http://uddin-zashim.com/bullsy/', 'new_window' : true },
                        { 'title':'Download', 'url':'http://uddin-zashim.com/bullsy/', 'new_window' : true}
                    ],
                    'tags'          : ['ECOMMERCE']
                },
                {
                    'title'         : 'CUDA',
                    'description'   : 'BULLSY is a parallel computing platform and programming model invented by NVIDIA. It enables dramatic increases in computing performance by harnessing the power of the graphics processing uni.....',
                    'thumbnail'     : ['images/small/cuda.jpg', 'images/small/bullsy.jpg'],
                    'large'         : ['images/large/cuda.jpg', 'images/large/bullsy.jpg'],
                    'button_list'   :
                    [
                        { 'title':'Demo', 'url' : 'http://uddin-zashim.com/cuda/', 'new_window' : true },
                        { 'title':'Download', 'url':'http://uddin-zashim.com/cuda/', 'new_window' : true}
                    ],
                    'tags'          : ['BRANDING']
                },
                {
                    'title'         : 'Contact',
                    'description'   : 'Contact is a parallel computing platform and programming model invented by NVIDIA. It enables dramatic increases in computing performance by harnessing the power of the graphics processing uni.....',
                    'thumbnail'     : ['images/small/contact.jpg','images/small/bullsy.jpg'],
                    'large'         : ['images/large/contact.jpg','images/large/bullsy.jpg'],
                    'button_list'   :
                    [
                        { 'title':'Demo', 'url' : 'http://uddin-zashim.com/', 'new_window' : true },
                        { 'title':'Download', 'url':'http://uddin-zashim.com/', 'new_window' : true}
                    ],
                    'tags'          : ['', '']
                },
                {
                    'title'         : 'persinal',
                    'description'   : 'personal chard pumpkin bunya nuts maize plantain aubergine napa cabbage soko coriander sweet pepper water spinach winter purslane shallot tigernut lentil beetroot.Swiss chard pumpkin bunya nuts maize plantain aubergine napa cabbage.',
                    'thumbnail'     : ['images/small/personal.jpg', 'images/small/bullsy.jpg'],
                    'large'         : ['images/large/personal.jpg', 'images/large/bullsy.jpg'],
                    'button_list'   :
                    [
                        { 'title':'Demo', 'url' : 'http://uddin-zashim.com/', 'new_window' : true },
                        { 'title':'Download', 'url':'http://uddin-zashim.com/', 'new_window' : true}
                    ],
                    'tags'          : ['PERSONAL']
                },
                {
                    'title'         : 'uranos',
                    'description'   : 'uranoschard pumpkin bunya nuts maize plantain aubergine napa cabbage soko coriander sweet pepper water spinach winter purslane shallot tigernut lentil beetroot.Swiss chard pumpkin bunya nuts maize plantain aubergine napa cabbage.',
                    'thumbnail'     : ['images/small/uranos.jpg', 'images/small/contact.jpg', 'images/small/19.jpg', 'images/small/20.jpg'],
                    'large'         : ['images/large/uranos.jpg', 'images/large/contact.jpg', 'images/large/19.jpg', 'images/large/20.jpg'],
                    'button_list'   :
                    [
                        { 'title':'Demo', 'url' : 'http://uddin-zashim.com/uranos/', 'new_window' : true },
                        { 'title':'Download', 'url':'http://uddin-zashim.com/uranos/', 'new_window' : true}
                    ],
                    'tags'          : ['LANDING PAGE']
                }
                
                

            ]
        });
		
		var link,
                toggleScrollToTopLink=function(){
                    if($("body").scrollTop()>0 ||
                            $("html").scrollTop()>0){
                        link.fadeIn(400);
                    }
                    else{
                        link,fadeOut(400);
                    }
                    
                };
                $(document).ready(function(){
                    link=$(".scroll-to-top-link");
                    $(window).scroll(toggleScrollToTopLink);
                    toggleScrollToTopLink();
                    link.on("click",function(){
                        $("body").animate({scrollTop:0});
                        $("html").animate({scrollTop:0});
                    });
                });
		
    
    
                $("body").addClass(".preloader_active");
                $(window).load(function(){
                    $("#preloader").fadeOut(3000);
                    $(".spiner_preloader").delay(30).fadeOut(fast);
                    $("body").removeClass("preloader_active");
                });
                    
                
		
    })();